from django.apps import AppConfig


class HtttsvConfig(AppConfig):
    name = 'HTTTSV'
